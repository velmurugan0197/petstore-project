$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/main/resources/FeatureFile/Testcase.feature");
formatter.feature({
  "name": "Pet Store Website",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@PetStoreProject"
    }
  ]
});
formatter.scenario({
  "name": "Register to the Pet Store website",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@PetStoreProject"
    },
    {
      "name": "@PetStore01"
    }
  ]
});
formatter.step({
  "name": "the user launch the browser",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinition.Register_SD.the_user_launch_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user open the Pet Store Home page using the link",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinition.Register_SD.the_user_open_the_Pet_Store_Home_page_using_the_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user enters the details to register",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinition.Register_SD.the_user_enters_the_details_to_register()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user clicks on register button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Register_SD.the_user_clicks_on_register_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user lands on the Home page to signin",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Register_SD.the_user_lands_on_the_Home_page_to_signin()"
});
formatter.result({
  "status": "passed"
});
formatter.scenarioOutline({
  "name": "Login to the Pet Store website with valid credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@PetStore02"
    }
  ]
});
formatter.step({
  "name": "the user launches the browser",
  "keyword": "Given "
});
formatter.step({
  "name": "the user open PetStore HomePage using the link",
  "keyword": "When "
});
formatter.step({
  "name": "the user enters valid \"\u003cUserName\u003e\" and \"\u003cPassword\u003e\"",
  "keyword": "And "
});
formatter.step({
  "name": "the user clicks on login button",
  "keyword": "Then "
});
formatter.step({
  "name": "the user lands on the Welcome page",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "UserName",
        "Password"
      ]
    },
    {
      "cells": [
        "testcase1",
        "password1"
      ]
    },
    {
      "cells": [
        "testcase2",
        "password2"
      ]
    },
    {
      "cells": [
        "testcase3",
        "password3"
      ]
    },
    {
      "cells": [
        "testcase4",
        "password4"
      ]
    },
    {
      "cells": [
        "testcase5",
        "password5"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Login to the Pet Store website with valid credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@PetStoreProject"
    },
    {
      "name": "@PetStore02"
    }
  ]
});
formatter.step({
  "name": "the user launches the browser",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_launches_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user open PetStore HomePage using the link",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_open_PetStore_HomePage_using_the_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user enters valid \"testcase1\" and \"password1\"",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_enters_valid_and(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_clicks_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user lands on the Welcome page",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_lands_on_the_Welcome_page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login to the Pet Store website with valid credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@PetStoreProject"
    },
    {
      "name": "@PetStore02"
    }
  ]
});
formatter.step({
  "name": "the user launches the browser",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_launches_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user open PetStore HomePage using the link",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_open_PetStore_HomePage_using_the_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user enters valid \"testcase2\" and \"password2\"",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_enters_valid_and(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_clicks_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user lands on the Welcome page",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_lands_on_the_Welcome_page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login to the Pet Store website with valid credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@PetStoreProject"
    },
    {
      "name": "@PetStore02"
    }
  ]
});
formatter.step({
  "name": "the user launches the browser",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_launches_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user open PetStore HomePage using the link",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_open_PetStore_HomePage_using_the_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user enters valid \"testcase3\" and \"password3\"",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_enters_valid_and(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_clicks_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user lands on the Welcome page",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_lands_on_the_Welcome_page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login to the Pet Store website with valid credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@PetStoreProject"
    },
    {
      "name": "@PetStore02"
    }
  ]
});
formatter.step({
  "name": "the user launches the browser",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_launches_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user open PetStore HomePage using the link",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_open_PetStore_HomePage_using_the_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user enters valid \"testcase4\" and \"password4\"",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_enters_valid_and(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_clicks_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user lands on the Welcome page",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_lands_on_the_Welcome_page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Login to the Pet Store website with valid credentials",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@PetStoreProject"
    },
    {
      "name": "@PetStore02"
    }
  ]
});
formatter.step({
  "name": "the user launches the browser",
  "keyword": "Given "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_launches_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user open PetStore HomePage using the link",
  "keyword": "When "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_open_PetStore_HomePage_using_the_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user enters valid \"testcase5\" and \"password5\"",
  "keyword": "And "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_enters_valid_and(java.lang.String,java.lang.String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user clicks on login button",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_clicks_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user lands on the Welcome page",
  "keyword": "Then "
});
formatter.match({
  "location": "com.stepdefinition.Login_SD.the_user_lands_on_the_Welcome_page()"
});
formatter.result({
  "status": "passed"
});
});