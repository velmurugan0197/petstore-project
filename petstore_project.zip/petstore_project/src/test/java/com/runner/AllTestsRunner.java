package com.runner;  

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/main/resources/FeatureFile/Testcase.feature",
		tags = {"@PetStoreProject"},
		glue = {"com.stepdefinition"},
		plugin = {	"pretty",
					"html:reports/PetStore_htmlReport.html",
					"json:reports/jsonreport/PetStore_jsonReport",
					"junit:reports/junit/PetStore_junitReport.xml"
					//"com.cucumber.listener.ExtentCucumberFormatter:target/Extentreports/Extentreport.html"
		 		 },
		monochrome = true,
		strict = true
		)
@SuiteClasses({})
public class AllTestsRunner {

}
