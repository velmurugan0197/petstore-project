package com.datadriven;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainDataDriven {

	public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
		
		DataDriven obj = new DataDriven();
		obj.ExcelUtility();

	}

}
